-- Andy Bodell
use CPSC4620Project;

SELECT * FROM topping;
SELECT * FROM pizza;
SELECT * FROM `order`;
SELECT * FROM discount;
SELECT * FROM customer;
SELECT * FROM orderdiscount;
SELECT * FROM pizzadiscount;
SELECT * FROM pizzatoppingrelationship;
SELECT * FROM baseprice;